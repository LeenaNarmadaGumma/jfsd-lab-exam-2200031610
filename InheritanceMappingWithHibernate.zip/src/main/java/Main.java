package com.klef.jfsd.exam;

import jakarta.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "Device")
public class Device {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String brand, model;
    private double price;

    public Device() {}
    public Device(String brand, String model, double price) {
        this.brand = brand; this.model = model; this.price = price;
    }
}
